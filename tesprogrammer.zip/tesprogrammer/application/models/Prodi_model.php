<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Prodi_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    // Mendapatkan semua data program studi
    public function get_all_prodi()
    {
        return $this->db->get('prodi')->result_array();
    }

    // Mendapatkan program studi berdasarkan ID
    public function get_prodi_by_id($id)
    {
        return $this->db->get_where('prodi', ['id' => $id])->row_array();
    }

    // Menambahkan program studi
    public function insert_prodi($data)
    {
        return $this->db->insert('prodi', $data);
    }

    // Memperbarui program studi berdasarkan ID
    public function update_prodi($id, $data)
    {
        $this->db->where('id', $id);
        return $this->db->update('prodi', $data);
    }

    // Menghapus program studi berdasarkan ID
    public function delete_prodi($id)
    {
        $this->db->where('id', $id);
        return $this->db->delete('prodi');
    }
}
