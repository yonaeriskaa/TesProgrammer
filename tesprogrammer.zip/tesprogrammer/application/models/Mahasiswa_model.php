<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Mahasiswa_model extends CI_Model
{
    public function __construct()
    {
        $this->load->database();
    }

    public function get_all_mahasiswa()
    {
        $query = $this->db->get('mahasiswa');
        return $query->result_array();
    }

    public function get_mahasiswa_by_nim($nim)
    {
        $query = $this->db->get_where('mahasiswa', array('nim' => $nim));
        return $query->row_array();
    }

    public function insert_mahasiswa()
    {
        $data = array(
            'nim' => $this->input->post('nim'),
            'nama' => $this->input->post('nama'),
            'prodi_id' => $this->input->post('prodi_id'),
            'tanggal_lahir' => $this->input->post('tanggal_lahir'),
            'password' => password_hash($this->input->post('password'), PASSWORD_DEFAULT) // Hash password
        );
        return $this->db->insert('mahasiswa', $data);
    }

    public function update_mahasiswa($nim)
    {
        $data = array(
            'nama' => $this->input->post('nama'),
            'prodi_id' => $this->input->post('prodi_id'),
            'tanggal_lahir' => $this->input->post('tanggal_lahir')
        );

        $password = $this->input->post('password');
        if (!empty($password)) {
            $data['password'] = password_hash($password, PASSWORD_DEFAULT); // Hash password if provided
        }

        $this->db->where('nim', $nim);
        return $this->db->update('mahasiswa', $data);
    }

    public function delete_mahasiswa($nim)
    {
        return $this->db->delete('mahasiswa', array('nim' => $nim));
    }
}
