<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Bayar_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    // Get all records
    public function get_all_bayar()
    {
        $query = $this->db->get('bayar');
        return $query->result_array();
    }

    // Get a single record by ID
    public function get_bayar($id)
    {
        $query = $this->db->get_where('bayar', array('id' => $id));
        return $query->row_array();
    }

    // Insert a new record
    public function insert_bayar($data)
    {
        return $this->db->insert('bayar', $data);
    }

    // Update a record
    public function update_bayar($id, $data)
    {
        $this->db->where('id', $id);
        return $this->db->update('bayar', $data);
    }

    // Delete a record
    public function delete_bayar($id)
    {
        $this->db->where('id', $id);
        return $this->db->delete('bayar');
    }
}
