<?php
class User_model extends CI_Model
{
    public function __construct()
    {
        $this->load->database();
    }

    public function login($nim, $password)
    {
        // Mengambil data mahasiswa berdasarkan NIM
        $this->db->where('nim', $nim);
        $query = $this->db->get('mahasiswa');

        // Memeriksa apakah ada hasil
        if ($query->num_rows() === 1) {
            $user = $query->row();

            // Verifikasi password
            if (password_verify($password, $user->password)) {
                return $user; // Pengguna valid, kembalikan data pengguna
            } else {
                // Password tidak cocok
                return false;
            }
        } else {
            // NIM tidak ditemukan
            return false;
        }
    }
    public function get_user_count()
{
    return $this->db->count_all('mahasiswa');
}

}
