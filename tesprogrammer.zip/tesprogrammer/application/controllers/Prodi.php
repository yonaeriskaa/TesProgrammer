<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Prodi extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Prodi_model');
    }

    public function index()
    {
        $data['title'] = 'Daftar Program Studi';
        $data['prodi'] = $this->Prodi_model->get_all_prodi();
        $this->load->view('templates/header', $data);
        $this->load->view('prodi/index', $data);
        $this->load->view('templates/footer');
    }

    public function create()
    {
        $this->load->helper('form');
        $this->load->library('form_validation');

        $data['title'] = 'Tambah Program Studi';

        $this->form_validation->set_rules('nama_prodi', 'Nama Program Studi', 'required');

        if ($this->form_validation->run() === FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('prodi/create');
            $this->load->view('templates/footer');
        } else {
            $this->Prodi_model->insert_prodi([
                'nama_prodi' => $this->input->post('nama_prodi')
            ]);
            redirect('prodi');
        }
    }

    public function edit($id)
    {
        $this->load->helper('form');
        $this->load->library('form_validation');

        $data['title'] = 'Edit Program Studi';
        $data['prodi'] = $this->Prodi_model->get_prodi_by_id($id);

        if (empty($data['prodi'])) {
            show_404();
        }

        $this->form_validation->set_rules('nama_prodi', 'Nama Program Studi', 'required');

        if ($this->form_validation->run() === FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('prodi/edit', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Prodi_model->update_prodi($id, [
                'nama_prodi' => $this->input->post('nama_prodi')
            ]);
            redirect('prodi');
        }
    }

    public function delete($id)
    {
        $this->Prodi_model->delete_prodi($id);
        redirect('prodi');
    }
}
