<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Auth extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('User_model');
    }

    public function login()
    {
        $this->load->helper(array('form', 'url'));

        if ($this->input->post()) {
            $nim = $this->input->post('nim');
            $password = $this->input->post('password');

            $user = $this->User_model->login($nim, $password);

            if ($user) {
                // Set session data here
                $this->session->set_userdata('user_id', $user->nim);
                redirect('dashboard');
            } else {
                $this->session->set_flashdata('error', 'Invalid NIM or Password');
                redirect('auth/login');
            }
        } else {
            $this->load->view('login');
        }
    }

    public function logout()
    {
        $this->session->unset_userdata('user_id');
        redirect('auth/login');
    }
}
