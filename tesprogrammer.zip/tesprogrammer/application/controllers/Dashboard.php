<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Dashboard extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('User_model'); // Memuat model User_model
        $this->load->library('session');
        $this->load->helper('url');
    }

    public function index()
    {
        // Cek apakah pengguna sudah login
        if (!$this->session->userdata('user_id')) {
            redirect('auth/login');
        }

        // Ambil data untuk dashboard, misalnya statistik atau laporan
        $data['title'] = 'Dashboard';
        $data['user_count'] = $this->User_model->get_user_count(); // Pastikan metode ini ada di model

        // Memuat tampilan header, dashboard, dan footer
        $this->load->view('templates/header', $data);
        $this->load->view('dashboard/index', $data);
        $this->load->view('templates/footer');
    }
}
