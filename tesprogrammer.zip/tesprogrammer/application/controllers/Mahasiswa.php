<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Mahasiswa extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Mahasiswa_model');
        $this->load->model('Prodi_model');
        $this->load->helper('url');
    }

    public function index()
    {
        $data['title'] = 'Daftar Mahasiswa';
        $data['mahasiswa'] = $this->Mahasiswa_model->get_all_mahasiswa();
        $this->load->view('templates/header', $data);
        $this->load->view('mahasiswa/index', $data);
        $this->load->view('templates/footer');
    }

    public function create()
    {
        $data['title'] = 'Tambah Mahasiswa';

        // Tambahkan data program studi
        $data['prodi_list'] = [
            1 => 'Teknik Informatika',
            2 => 'Sistem Informasi',
            3 => 'Teknik Mesin'
        ];

        $this->load->library('form_validation');
        $this->form_validation->set_rules('nim', 'NIM', 'required');
        $this->form_validation->set_rules('nama', 'Nama', 'required');
        $this->form_validation->set_rules('prodi_id', 'Program Studi', 'required');
        $this->form_validation->set_rules('tanggal_lahir', 'Tanggal Lahir', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');

        if ($this->form_validation->run() === FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('mahasiswa/create', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Mahasiswa_model->insert_mahasiswa();
            redirect('mahasiswa');
        }
    }

    public function edit($nim)
    {
        $data['title'] = 'Edit Mahasiswa';
        $data['mahasiswa'] = $this->Mahasiswa_model->get_mahasiswa_by_nim($nim);

        // Tambahkan data program studi
        $data['prodi_list'] = [
            1 => 'Teknik Informatika',
            2 => 'Sistem Informasi',
            3 => 'Teknik Mesin'
        ];

        $this->load->library('form_validation');
        $this->form_validation->set_rules('nim', 'NIM', 'required');
        $this->form_validation->set_rules('nama', 'Nama', 'required');
        $this->form_validation->set_rules('prodi_id', 'Program Studi', 'required');
        $this->form_validation->set_rules('tanggal_lahir', 'Tanggal Lahir', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required');

        if ($this->form_validation->run() === FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('mahasiswa/edit', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Mahasiswa_model->update_mahasiswa($nim);
            redirect('mahasiswa');
        }
    }

    public function delete($nim)
    {
        $this->Mahasiswa_model->delete_mahasiswa($nim);
        redirect('mahasiswa');
    }

    public function view($nim)
    {
        $data['title'] = 'Detail Mahasiswa';
        $data['mahasiswa'] = $this->Mahasiswa_model->get_mahasiswa_by_nim($nim);

        $this->load->view('templates/header', $data);
        $this->load->view('mahasiswa/view', $data);
        $this->load->view('templates/footer');
    }

    public function report()
    {
        $data['title'] = 'Laporan Data Siswa';
        $data['mahasiswa'] = $this->Mahasiswa_model->get_all_mahasiswa();

        // Load the view for the report
        $this->load->view('templates/header', $data);
        $this->load->view('mahasiswa/report', $data);
        $this->load->view('templates/footer');
    }
}
