<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Bayar extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Bayar_model');
        $this->load->helper('url');
    }

    public function index()
    {
        $data['title'] = 'Daftar Pembayaran';
        $data['bayar'] = $this->Bayar_model->get_all_bayar();
        $this->load->view('templates/header', $data);
        $this->load->view('bayar/index', $data);
        $this->load->view('templates/footer');
    }

    public function view($id)
    {
        $data['title'] = 'Detail Pembayaran';
        $data['bayar'] = $this->Bayar_model->get_bayar($id);
        if (empty($data['bayar'])) {
            show_404();
        }
        $this->load->view('templates/header', $data);
        $this->load->view('bayar/view', $data);
        $this->load->view('templates/footer');
    }

    public function create()
    {
        $data['title'] = 'Tambah Pembayaran';
        if ($this->input->post()) {
            $postData = array(
                'tanggal' => $this->input->post('tanggal'),
                'id_jenis_bayar' => $this->input->post('id_jenis_bayar'),
                'id_mahasiswa' => $this->input->post('id_mahasiswa'),
                'jumlah' => $this->input->post('jumlah')
            );
            $this->Bayar_model->insert_bayar($postData);
            redirect('bayar');
        }
        $this->load->view('templates/header', $data);
        $this->load->view('bayar/create');
        $this->load->view('templates/footer');
    }

    public function edit($id)
    {
        $data['title'] = 'Edit Pembayaran';
        $data['bayar'] = $this->Bayar_model->get_bayar($id);

        if (empty($data['bayar'])) {
            show_404();
        }

        if ($this->input->post()) {
            $postData = array(
                'tanggal' => $this->input->post('tanggal'),
                'id_jenis_bayar' => $this->input->post('id_jenis_bayar'),
                'id_mahasiswa' => $this->input->post('id_mahasiswa'),
                'jumlah' => $this->input->post('jumlah')
            );
            $this->Bayar_model->update_bayar($id, $postData);
            redirect('bayar');
        }

        $this->load->view('templates/header', $data);
        $this->load->view('bayar/edit', $data);
        $this->load->view('templates/footer');
    }

    public function delete($id)
    {
        $this->Bayar_model->delete_bayar($id);
        redirect('bayar');
    }
}
