</div> <!-- End of Content Wrapper -->
<!-- Footer -->
<footer class="sticky-footer bg-white">
    <div class="container my-auto">
    </div>
</footer>
<!-- End of Footer -->

<!-- Scripts -->
<script src="<?php echo base_url('assets/js/sb-admin-2.min.js'); ?>"></script>
</body>

</html>