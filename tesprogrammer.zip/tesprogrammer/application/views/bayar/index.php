<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800"><?php echo $title; ?></h1>
    <a href="<?php echo site_url('bayar/create'); ?>" class="btn btn-primary mb-3">Tambah Pembayaran</a>
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Daftar Pembayaran</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Tanggal</th>
                            <th>ID Jenis Bayar</th>
                            <th>ID Mahasiswa</th>
                            <th>Jumlah</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($bayar as $b) : ?>
                            <tr>
                                <td><?php echo $b['id']; ?></td>
                                <td><?php echo $b['tanggal']; ?></td>
                                <td><?php echo $b['id_jenis_bayar']; ?></td>
                                <td><?php echo $b['id_mahasiswa']; ?></td>
                                <td><?php echo $b['jumlah']; ?></td>
                                <td>
                                    <a href="<?php echo site_url('bayar/view/' . $b['id']); ?>" class="btn btn-info btn-sm">Lihat</a>
                                    <a href="<?php echo site_url('bayar/edit/' . $b['id']); ?>" class="btn btn-warning btn-sm">Edit</a>
                                    <a href="<?php echo site_url('bayar/delete/' . $b['id']); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus?');">Hapus</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>