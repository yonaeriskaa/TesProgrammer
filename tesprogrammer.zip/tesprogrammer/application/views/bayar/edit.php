<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800"><?php echo $title; ?></h1>
    <form action="<?php echo site_url('bayar/edit/' . $bayar['id']); ?>" method="post">
        <div class="form-group">
            <label for="tanggal">Tanggal</label>
            <input type="date" class="form-control" id="tanggal" name="tanggal" value="<?php echo $bayar['tanggal']; ?>" required>
        </div>
        <div class="form-group">
            <label for="id_jenis_bayar">ID Jenis Bayar</label>
            <input type="number" class="form-control" id="id_jenis_bayar" name="id_jenis_bayar" value="<?php echo $bayar['id_jenis_bayar']; ?>" required>
        </div>
        <div class="form-group">
            <label for="id_mahasiswa">ID Mahasiswa</label>
            <input type="text" class="form-control" id="id_mahasiswa" name="id_mahasiswa" value="<?php echo $bayar['id_mahasiswa']; ?>" required>
        </div>
        <div class="form-group">
            <label for="jumlah">Jumlah</label>
            <input type="number" step="0.01" class="form-control" id="jumlah" name="jumlah" value="<?php echo $bayar['jumlah']; ?>" required>
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
        <a href="<?php echo site_url('bayar'); ?>" class="btn btn-secondary">Kembali</a>
    </form>
</div>