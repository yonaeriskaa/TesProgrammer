<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800"><?php echo $title; ?></h1>
    <form action="<?php echo site_url('bayar/create'); ?>" method="post">
        <!-- Input Tanggal -->
        <div class="form-group">
            <label for="tanggal">Tanggal</label>
            <input type="date" class="form-control" id="tanggal" name="tanggal" required>
        </div>

        <!-- Input ID Jenis Bayar -->
        <div class="form-group">
            <label for="id_jenis_bayar">ID Jenis Bayar</label>
            <input type="number" class="form-control" id="id_jenis_bayar" name="id_jenis_bayar" required>
        </div>

        <!-- Input ID Mahasiswa -->
        <div class="form-group">
            <label for="id_mahasiswa">ID Mahasiswa</label>
            <input type="text" class="form-control" id="id_mahasiswa" name="id_mahasiswa" required>
        </div>

        <!-- Dropdown Program Studi -->
        <div class="form-group">
            <label for="prodi_id">Program Studi</label>
            <select class="form-control" id="prodi_id" name="prodi_id" required>
                <option value="">Pilih Program Studi</option>
                <option value="1">Teknik Informatika</option>
                <option value="2">Sistem Informasi</option>
                <option value="3">Teknik Mesin</option>
            </select>
        </div>

        <!-- Input Jumlah -->
        <div class="form-group">
            <label for="jumlah">Jumlah</label>
            <input type="number" step="0.01" class="form-control" id="jumlah" name="jumlah" required>
        </div>

        <!-- Tombol Submit dan Kembali -->
        <button type="submit" class="btn btn-primary">Simpan</button>
        <a href="<?php echo site_url('bayar'); ?>" class="btn btn-secondary">Kembali</a>
    </form>
</div>