<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800"><?php echo $title; ?></h1>
    <table class="table table-bordered">
        <tr>
            <th>ID</th>
            <td><?php echo $bayar['id']; ?></td>
        </tr>
        <tr>
            <th>Tanggal</th>
            <td><?php echo $bayar['tanggal']; ?></td>
        </tr>
        <tr>
            <th>ID Jenis Bayar</th>
            <td><?php echo $bayar['id_jenis_bayar']; ?></td>
        </tr>
        <tr>
            <th>ID Mahasiswa</th>
            <td><?php echo $bayar['id_mahasiswa']; ?></td>
        </tr>
        <tr>
            <th>Jumlah</th>
            <td><?php echo $bayar['jumlah']; ?></td>
        </tr>
    </table>
    <a href="<?php echo site_url('bayar'); ?>" class="btn btn-secondary">Kembali</a>
</div>