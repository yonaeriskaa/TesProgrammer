<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800"><?php echo $title; ?></h1>

    <?php echo form_open('prodi/edit/' . $prodi['id']); ?>

    <div class="form-group">
        <label for="nama_prodi">Nama Program Studi</label>
        <input type="text" class="form-control" id="nama_prodi" name="nama_prodi" value="<?php echo set_value('nama_prodi', $prodi['nama_prodi']); ?>">
        <?php echo form_error('nama_prodi'); ?>
    </div>

    <button type="submit" class="btn btn-primary">Update</button>
    <?php echo form_close(); ?>
</div>