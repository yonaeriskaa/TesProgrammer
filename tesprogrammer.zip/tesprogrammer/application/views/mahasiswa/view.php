<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800"><?php echo $title; ?></h1>

    <table class="table table-bordered">
        <tr>
            <th>NIM</th>
            <td><?php echo $mahasiswa['nim']; ?></td>
        </tr>
        <tr>
            <th>Nama</th>
            <td><?php echo $mahasiswa['nama']; ?></td>
        </tr>
        <tr>
            <th>Program Studi</th>
            <td><?php echo $mahasiswa['prodi_id']; ?></td>
        </tr>
        <tr>
            <th>Tanggal Lahir</th>
            <td><?php echo $mahasiswa['tanggal_lahir']; ?></td>
        </tr>
        <tr>
            <th>Password</th>
            <td><?php echo $mahasiswa['password']; ?></td>
        </tr>
    </table>
    <a href="<?php echo site_url('mahasiswa'); ?>" class="btn btn-primary">Kembali</a>
</div>
