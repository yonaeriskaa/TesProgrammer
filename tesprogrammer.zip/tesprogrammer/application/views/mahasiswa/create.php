<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800"><?php echo $title; ?></h1>

    <?php echo form_open('mahasiswa/create'); ?>
    <div class="form-group">
        <label for="nim">NIM</label>
        <input type="text" class="form-control" name="nim" placeholder="Enter NIM">
        <?php echo form_error('nim'); ?>
    </div>
    <div class="form-group">
        <label for="nama">Nama</label>
        <input type="text" class="form-control" name="nama" placeholder="Enter Nama">
        <?php echo form_error('nama'); ?>
    </div>
    <div class="form-group">
        <label for="prodi_id">Program Studi</label>
        <select class="form-control" id="prodi_id" name="prodi_id">
            <?php foreach ($prodi_list as $key => $value) : ?>
                <option value="<?php echo $key; ?>"><?php echo $value; ?></option>
            <?php endforeach; ?>
        </select>
    </div>

    <div class="form-group">
        <label for="tanggal_lahir">Tanggal Lahir</label>
        <input type="date" class="form-control" name="tanggal_lahir">
        <?php echo form_error('tanggal_lahir'); ?>
    </div>
    <!-- <div class="form-group">
        <label for="password">Password</label>
        <input type="password" class="form-control" name="password" placeholder="Enter Password">
        <?php echo form_error('password'); ?>
    </div> -->
    <button type="submit" class="btn btn-primary">Submit</button>
    <?php echo form_close(); ?>
</div>