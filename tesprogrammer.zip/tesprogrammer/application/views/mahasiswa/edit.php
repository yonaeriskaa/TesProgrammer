<!-- Begin Page Content -->
<div class="container-fluid">
    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?php echo $title; ?></h1>

    <!-- Form Edit Mahasiswa -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Edit Mahasiswa</h6>
        </div>
        <div class="card-body">
            <?php echo validation_errors(); ?>

            <?php echo form_open('mahasiswa/edit/' . $mahasiswa['nim']); ?>

            <div class="form-group">
                <label for="nama">Nama</label>
                <input type="text" class="form-control" name="nama" value="<?php echo $mahasiswa['nama']; ?>" />
            </div>

            <div class="form-group">
                <label for="prodi_id">Program Studi</label>
                <input type="number" class="form-control" name="prodi_id" value="<?php echo $mahasiswa['prodi_id']; ?>" />
            </div>

            <div class="form-group">
                <label for="tanggal_lahir">Tanggal Lahir</label>
                <input type="date" class="form-control" name="tanggal_lahir" value="<?php echo $mahasiswa['tanggal_lahir']; ?>" />
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" class="form-control" name="password" />
            </div>

            <button type="submit" class="btn btn-primary">Update Mahasiswa</button>
            <a href="<?php echo site_url('mahasiswa'); ?>" class="btn btn-secondary">Kembali</a>

            </form>
        </div>
    </div>
</div>
<!-- End of Page Content -->
</div>
<!-- Footer -->
<?php $this->load->view('templates/footer'); ?>
</div>