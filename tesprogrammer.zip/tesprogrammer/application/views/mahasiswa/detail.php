<div class="container-fluid d-flex justify-content-center">
    <!-- Card dengan ukuran sedang -->
    <div class="col-md-6">
        <h1 class="h3 mb-4 text-gray-800 text-center">Detail mahasiswa</h1>

        <!-- Card -->
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary text-center">mahasiswa Details</h6>
            </div>
            <div class="card-body">
                <?php if (!empty($mahasiswa)) : ?>
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped text-center">
                            <tbody>
                                <tr>
                                    <th>ID</th>
                                    <td><?= $mahasiswa['id'] ?></td>
                                </tr>
                                <tr>
                                    <th>Nama</th>
                                    <td><?= $mahasiswa['name'] ?></td>
                                </tr>
                                <tr>
                                    <th>Deskripsi</th>
                                    <td><?= $mahasiswa['description'] ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                <?php else : ?>
                    <p>mahasiswa tidak dmahasiswaukan.</p>
                <?php endif; ?>
            </div>
            <div class="card-footer text-right">
                <a href="<?= site_url('mahasiswas') ?>" class="btn btn-secondary">Kembali</a>
            </div>
        </div>
    </div>
</div>